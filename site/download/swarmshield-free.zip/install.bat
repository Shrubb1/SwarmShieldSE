@echo off
REM SwarmShieldSE install - desktop + Start Menu shortcuts, launches app.
setlocal
set RULES=9101:8081
echo installing SwarmShieldSE...
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\SwarmShieldSE.lnk');$s.TargetPath='%~dp0swarm_gui.exe';$s.Save();$m=(New-Object -COM WScript.Shell).CreateShortcut('%APPDATA%\Microsoft\Windows\Start Menu\Programs\SwarmShieldSE.lnk');$m.TargetPath='%~dp0swarm_gui.exe';$m.Save()" 2>nul
echo   desktop:  %USERPROFILE%\Desktop\SwarmShieldSE.lnk
echo   startmenu: searchable as "SwarmShieldSE"
echo.
echo For the background service (runs without login):
echo   admin: sc create SwarmShieldSE binPath= "%~dp0swarmshield.exe %RULES%" start= auto
echo   then:  sc start SwarmShieldSE
echo.
start "" "%~dp0swarm_gui.exe"
