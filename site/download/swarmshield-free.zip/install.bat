@echo off
REM SwarmShieldSE install - registers the guard service + desktop app.
setlocal
set RULES=9101:8081
echo installing SwarmShieldSE...
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\SwarmShieldSE.lnk');$s.TargetPath='%~dp0swarm_gui.exe';$s.Save()" 2>nul
echo   app: %USERPROFILE%\Desktop\SwarmShieldSE.lnk
echo.
echo For the background service (runs without login):
echo   admin: sc create SwarmShieldSE binPath= "%~dp0swarmshield.exe %RULES%" start= auto
echo   then:  sc start SwarmShieldSE
echo.
echo Run the app now? (the desktop icon does the same)
start "" "%~dp0swarm_gui.exe"
